# VmessSpeed

This is a project froked from: https://github.com/showwin/speedtest-go

This tool accepts a vmess link and connects to the speedtest.net servers, then reports the speed info.

